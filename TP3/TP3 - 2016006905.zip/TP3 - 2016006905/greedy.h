#ifndef GREEDY_H
#define GREEDY_H

int patienceSorting (int *v, int n);

#endif
