#ifndef DYNAMIC_H
#define DYNAMIC_H

int dynamicLIS(int *v, int n);

int CeilIndex(int *v, int l, int r, int key) ;

#endif
