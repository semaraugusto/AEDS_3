#ifndef BRUTEFORCE_H
#define BRUTEFORCE_H

int bruteForceLIS(int *v, int n);

#endif
